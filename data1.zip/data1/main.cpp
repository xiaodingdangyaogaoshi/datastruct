#include "widget.h"
#include <QApplication>

#include<QLabel>
#include<QPushButton>
#include<QWidget>
#include <iostream>
#include <ctime>
#include<QPainter>
using namespace std;
typedef long long LL;
#define MAX 30010
#define INF 1<<30
#define MAXcost 1024

struct edge {
    int to;
    LL cost;
}temp;
int V;//顶点数
int n;//线数
vector<edge>G[MAX];
LL d[MAX];//距离数组
int used[MAX];//判断压栈
int temparray[5][5];
int tempcost[5][5];

vector<int>linkpoint [5];
int destination[5];
int cross[5][5];

int randfrom;
int pcross[5];


static int clickcount=0;

void dij() {
    for(int i=0;i<V;i++){
        int p = 0;
       //d[p]即d[0]是无穷大
        for (int i =1; i <= V; i++) {
            if (d[i] < d[p] && used[i] == 0)
                p = i;
        }//找出距离最小的点
        if (p == 0)
            break;
        used[p] = 1;
        pcross[i]=p;
        cout<<"pppppppppppp"<<p<<endl;
        for (int i = 0; i < G[p].size(); i++) {
            cout<<"dpdpdpdppdpdpdpdpp"<<d[p]<<endl;
            d[G[p][i].to] = min(d[G[p][i].to], d[p] + G[p][i].cost);
            cout<<"p"<<p<<"i"<<i<<"d[G[p][i].to"<<d[G[p][i].to]<<endl;
        }//用距离最小的点松弛
    }
}
void init(){
        //ios::sync_with_stdio(false);
        srand(unsigned(time(NULL)));
        //V个学生 n个关系 下标从1开始
        V=4+rand()%2;
        cout<<"V"<<V<<endl;
        n=15+rand()%10;
        cout<<"n"<<n<<endl;
        int besure[10][10];
        for (int i=0;i<=V;i++) {
            for (int j=0;j<=V;j++) {
                besure[i][j]=0;
            }
        }
        for(int i=0;i<V;i++){
            pcross[i]=0;
        }
        for (int i = 0; i < n; i++) {
            edge temp;
            int from;
            from=1+rand()%V;
            temp.to=1+rand()%V;
            if(besure[from][temp.to]!=1&&from!=temp.to){
            besure[from][temp.to]=1;
            besure[temp.to][from]=1;
            temp.cost=3+rand()%15;
            cout<<"i"<<i<<endl;
            cout<<"from"<<from<<"to"<<temp.to<<"cost"<<temp.cost<<endl;

            G[from].push_back(temp);

            }
        }
        //fill(d, d + V + 1, INF);
        for (int i = 0; i <= V; i++)
            d[i] = INF;
        memset(used,0,sizeof(used));

        randfrom=1+rand()%V;
        cout<<"randfrom"<<randfrom<<endl;
        for (int i = 0; i < G[randfrom].size(); i++) {
            d[G[randfrom][i].to] = G[randfrom][i].cost;

        }
      //将vector改为数组
        for (int i=0;i<5;i++) {
            for(int j=0;j<5;j++){
                temparray[i][j]=0;
            }
        }
        for(int i=1;i<=V;i++){
            int temp=G[i].size();
            for (int j=0;j<temp;j++) {
                temparray[i-1][j]=G[i][j].to;

            }
        }
        for (int i=0;i<5;i++) {
            for (int j=0;j<5;j++) {
                tempcost[i][j]=MAXcost;
            }
        }
        for (int i=1;i<=V;i++) {
            int temp=G[i].size();
            for (int j=0;j<temp;j++) {
                tempcost[i-1][j]=G[i][j].cost;
            }
        }
        d[randfrom] = 0;//初始化
        dij();
        for(int i=0;i<=V;i++){
             printf("%lld\n", d[i]);
        }
}
void Widget::on_Next_clicked()
{
    QLabel *link1=new QLabel(this);
    link1->move(50,520);
    QLabel *link2=new QLabel(this);
    link2->move(50,540);
    QLabel *link3=new QLabel(this);
    link3->move(50,560);
    QLabel *link4=new QLabel(this);
    link4->move(50,580);
    QLabel *link5=new QLabel (this);
    link5->move(50,600);
    QLabel *bool1=new QLabel(this);
    bool1->move(100,520);
    QLabel *bool2=new QLabel(this);
    bool2->move(100,540);
    QLabel *bool3=new QLabel(this);
    bool3->move(100,560);
    QLabel *bool4=new QLabel(this);
    bool4->move(100,580);
    QLabel *bool5=new QLabel(this);
    bool5->move(100,600);
    QLabel *dis1=new QLabel(this);
    dis1->move(150,520);
    QLabel *dis2=new QLabel(this);
    dis2->move(150,540);
    QLabel *dis3=new QLabel(this);
    dis3->move(150,560);
    QLabel *dis4=new QLabel(this);
    dis4->move(150,580);
    QLabel *dis5=new QLabel(this);
    dis5->move(150,600);


    clickcount++;
    if(clickcount==1){
        link1->setNum(1);
        link1->show();
        if(d[1]!=1073741824){
            bool1->setText("Y");

            bool1->show();
        }
        else {
            bool1->setText("N");
            bool1->show();
        }
        int temp1=d[1];
        dis1->setNum(temp1);
        dis1->show();
    }
    if(clickcount==2){
        link2->setNum(2);
        link2->show();
        if(d[2]!=1073741824){
            bool2->setText("Y");

            bool2->show();
        }
        else {
            bool2->setText("N");
            bool2->show();
        }
        int temp2=d[2];
        dis2->setNum(temp2);
        dis2->show();
    }
    if(clickcount==3){
        link3->setNum(3);
        link3->show();
        if(d[3]!=1073741824){
            bool3->setText("Y");

            bool3->show();
        }
        else {
            bool3->setText("N");
            bool3->show();
        }
        int temp3=d[3];
        dis3->setNum(temp3);
        dis3->show();
    }
    if(clickcount==4){
        link4->setNum(4);
        link4->show();
        if(d[4]!=1073741824){
            bool4->setText("Y");

            bool4->show();
        }
        else {
            bool4->setText("N");
            bool4->show();
        }
        int temp4=d[4];
        dis4->setNum(temp4);
        dis4->show();
    }
    if(clickcount==5&&V==5){
        link5->setNum(pcross[5]);
        link5->show();
        if(d[5]!=1073741824){
            bool5->setText("Y");

            bool5->show();
        }
        else {
            bool5->setText("N");
            bool5->show();
        }
        int temp5=d[5];
        dis5->setNum(temp5);
        dis5->show();
    }

}
void Widget::paintEvent(QPaintEvent *){
    QPainter p;
    p.begin(this);
    p.drawPixmap(rect(),QPixmap("../image/nb.jpg"));


    QPainter qpainterpoint;
    qpainterpoint.begin(this);
    QPen penpoint;
    penpoint.setColor(Qt::green);
    penpoint.setWidth(2);
    qpainterpoint.setPen(penpoint);

    QPen pen;
    pen.setWidth(3);
    pen.setColor(Qt::gray);
    //pen.setColor(QColor());
    pen.setStyle(Qt::DashLine);
    p.setPen(pen);

    QPen pen2;
    pen2.setWidth(3);
    pen2.setColor(Qt::gray);
    //pen.setColor(QColor());
    pen2.setStyle(Qt::DashLine);
    p.setPen(pen2);

    QPainter painter;
    painter.begin(this);
    painter.setPen(pen2);

    QPen pento;
    pento.setWidth(5);
    pento.setColor(Qt::red);
    pento.setStyle(Qt::DashLine);

    QPainter qpainterto;
    qpainterto.begin(this);
    qpainterto.setPen(pento);

    if(V==4)
    {
    //
    for(int i=1;i<=V;i++){

             p.drawPixmap(110,90,60,60,QPixmap("../iamge/face.jpg"));

             p.drawPixmap(110,270,60,60,QPixmap("../iamge/face.jpg"));

             p.drawPixmap(330,90,60,60,QPixmap("../iamge/face.jpg"));

             p.drawPixmap(330,270,60,60,QPixmap("../iamge/face.jpg"));

       }
    }
    if(V==5){
        for(int i=1;i<=V;i++)
            {
            if(i<=2){
                 p.drawPixmap(100*(2.2*i-1),90,60,60,QPixmap("../iamge/face.jpg"));
            }
            else{
                 p.drawPixmap(90,285,60,60,QPixmap("../iamge/face.jpg"));
                  p.drawPixmap(230,400,60,60,QPixmap("../iamge/face.jpg"));
                   p.drawPixmap(360,285,60,60,QPixmap("../iamge/face.jpg"));
            }

           }
    }
    //画距离线
    //设置线段
    QPainter qpainterline;
    qpainterline.begin(this);
    qpainterline.setPen(pen);
    if(V==4){
        for (int i=0;i<V;i++) {
            for (int j=0;j<V;j++) {
                int tempto=temparray[i][j];
                if(tempto!=0){
                    if(i+1==1){
                        switch (tempto) {
                         case 2:
                            qpainterline.drawLine(140,120,330,120);
                            qpainterto.drawEllipse(310,116,10,10);
                            break;
                          case 3:
                            qpainterline.drawLine(140,120,140,300);
                            qpainterto.drawEllipse(135,260,10,10);
                            break;
                           case 4:
                            qpainterline.drawLine(140,120,360,300);
                            qpainterto.drawEllipse(310,268,10,10);
                            break;
                        }
                    }
                    if(i+1==2){
                        switch (tempto) {
                        case 1:
                            qpainterline.drawLine(360,120,140,120);
                            qpainterto.drawEllipse(180,116,10,10);
                            break;

                          case 3:
                            qpainterline.drawLine(360,120,140,300);
                            qpainterto.drawEllipse(170,260,10,10);
                            break;
                           case 4:
                            qpainterline.drawLine(360,120,360,300);
                            qpainterto.drawEllipse(360,276,10,10);
                            break;
                        }
                    }
                    if(i+1==3){
                        switch (tempto) {
                        case 1:
                            qpainterline.drawLine(140,300,140,120);
                            qpainterto.drawEllipse(140,170,10,10);
                            break;
                         case 2:
                            qpainterline.drawLine(140,300,360,120);
                            qpainterto.drawEllipse(325,160,10,10);
                            break;

                         case 4:
                            qpainterline.drawLine(140,300,360,300);
                            qpainterto.drawEllipse(290,282,10,10);
                            break;
                        }
                    }
                    if(i+1==4){
                        switch (tempto) {
                        case 1:
                            qpainterline.drawLine(360,300,140,120);
                            qpainterto.drawEllipse(160,140,10,10);
                            break;
                         case 2:
                            qpainterline.drawLine(360,300,360,120);
                            painter.drawEllipse(360,140,10,10);
                            break;
                         case 3:
                            qpainterline.drawLine(360,300,140,300);
                            qpainterto.drawEllipse(320,296,10,10);
                            break;

                        }
                    }
                }
            }
        }
    }

    if(V==5){
        for (int i=0;i<V;i++) {
            for (int j=0; j<V;j++) {
                int tempF=temparray[i][j];
                if(tempF!=0){
                    if(i+1==1){
                        switch (tempF) {

                         case 2:
                            qpainterline.drawLine(140,120,370,120);
                            qpainterto.drawEllipse(350,100,10,10);
                            break;
                         case 3:
                            qpainterline.drawLine(140,120,120,315);
                            qpainterto.drawEllipse(120,255,10,10);
                            break;
                          case 4:
                            qpainterline.drawLine(140,120,260,430);
                            qpainterto.drawEllipse(240,360,10,10);
                            break;
                          case 5:
                            qpainterline.drawLine(140,120,390,315);
                            qpainterto.drawEllipse(355,275,10,10);
                            break;
                        }

                    }
                    if(i+1==2){
                        switch (tempF) {
                         case 1:
                            qpainterline.drawLine(370,120,150,120);
                            qpainterto.drawEllipse(180,120,10,10);
                            break;

                         case 3:
                            qpainterline.drawLine(370,120,120,315);
                            qpainterto.drawEllipse(130,290,10,10);
                            break;
                         case 4:
                            qpainterline.drawLine(370,120,260,430);
                            qpainterto.drawEllipse(270,380,10,10);
                            break;
                         case 5:
                            qpainterline.drawLine(370,120,390,315);
                            qpainterto.drawEllipse(375,270,10,10);
                            break;

                        }
                    }
                    if(i+1==3){
                        switch (tempF) {
                        case 1:
                            qpainterline.drawLine(120,315,150,120);
                            qpainterto.drawEllipse(130,155,10,10);
                            break;
                         case 2:
                            qpainterline.drawLine(120,315,380,120);
                            qpainterto.drawEllipse(330,118,10,10);
                            break;

                          case 4:
                            qpainterline.drawLine(120,315,260,430);
                            qpainterto.drawEllipse(225,400,10,10);
                            break;
                          case 5:
                            qpainterline.drawLine(120,315,390,315);
                            qpainterto.drawEllipse(370,285,10,10);
                            break;

                        }
                    }
                    if(i+1==4){
                        switch (tempF) {
                        case 1:
                            qpainterline.drawLine(260,430,150,120);
                            qpainterto.drawEllipse(165,180,10,10);
                            break;
                         case 2:
                            qpainterline.drawLine(260,430,370,120);
                            qpainterto.drawEllipse(330,150,10,10);
                            break;
                         case 3:
                            qpainterline.drawLine(260,430,120,315);
                            qpainterto.drawEllipse(140,335,10,10);
                            break;

                         case 5:
                            qpainterline.drawLine(260,430,390,315);
                            qpainterto.drawEllipse(355,340,10,10);
                            break;
                        }
                    }
                    if(i+1==5){
                        switch(tempF){
                        case 1:
                            qpainterline.drawLine(390,315,150,120);
                            qpainterto.drawEllipse(170,140,10,10);
                            break;
                        case 2:
                            qpainterline.drawLine(390,315,370,120);
                            qpainterto.drawEllipse(350,140,10,10);
                            break;
                        case 3:
                            qpainterline.drawLine(390,315,120,315);
                            qpainterto.drawEllipse(160,315,10,10);
                            break;
                        case 4:
                            qpainterline.drawLine(390,315,260,430);
                            qpainterto.drawEllipse(300,380,10,10);
                            break;

                        }
                    }
                }
            }
        }
    }


    p.end();

    //又到了exin的设置label位置的时候啦
    //4个元素的时候
    if(V==4){

    QLabel *qlabel41= new QLabel(this);
    qlabel41->move(250,120);

    QLabel *qlabel42= new QLabel(this);
    qlabel42->move(140,210);

    QLabel *qlabel43= new QLabel(this);
    qlabel43->move(250,300);

    QLabel *qlabel44= new QLabel(this);
    qlabel44->move(360,240);

    QLabel *qlabel45= new QLabel(this);
    qlabel45->move(200,218);

    QLabel *qlabel46= new QLabel(this);
    qlabel46->move(300,150);




    for (int i=0;i<V;i++) {
        for(int j=0;j<V;j++){
            int tempC=tempcost[i][j];
            if(i+1==1&&tempC!=1024){
                switch (j+1) {

                case 2:
                    qlabel41->setNum(tempC);
                    qlabel41->show();
                    break;
                case 3:
                    qlabel42->setNum(tempC);
                    qlabel42->show();
                    break;
                case 4:
                    qlabel45->setNum(tempC);
                    qlabel45->show();
                    break;
                }
            }
            if(i+1==2&&tempC!=1024){
                switch (j+1) {
                case 1:
                    qlabel41->setNum(tempC);
                    qlabel41->show();
                    break;

                case 3:
                    qlabel46->setNum(tempC);
                    qlabel46->show();
                    break;
                case 4:
                    qlabel44->setNum(tempC);
                    qlabel44->show();
                    break;

                }

            }
            if(i+1==3&&tempC!=1024){
                switch (j+1) {
                case 1:
                    qlabel42->setNum(tempC);
                    qlabel42->show();
                    break;
                 case 2:
                    qlabel46->setNum(tempC);
                    qlabel46->show();
                    break;
                 case 4:
                    qlabel43->setNum(tempC);
                    qlabel43->show();

                }
            }
            if(i+1==4&&tempC!=1024){
                switch (j+1) {
                case 1:
                    qlabel45->setNum(tempC);
                    qlabel45->show();
                    break;
                case 2:
                    qlabel44->setNum(tempC);
                    qlabel44->show();
                    break;
                case 3:
                    qlabel43->setNum(tempC);
                    qlabel43->show();
                    break;
                }
            }

        }
    }
 }
    if(V==5){
       QLabel *qlabel51=new  QLabel(this);
       qlabel51->move(260,120);
       QLabel *qlabel52=new QLabel(this);
       qlabel52->move(135,218);
       QLabel*qlabel53=new QLabel(this);
       qlabel53->move(185,373);
       QLabel *qlabel54=new QLabel(this);
       qlabel54->move(320,373);
       QLabel *qlabel55=new  QLabel(this);
       qlabel55->move(380,218);
       QLabel *qlabel56=new QLabel(this);
       qlabel56->move(270,218);
       QLabel *qlabel57=new QLabel(this);
       qlabel57->move(245,218);
       QLabel *qlabel58=new QLabel(this);
       qlabel58->move(200,275);
       QLabel *qlabel59=new QLabel(this);
       qlabel59->move(310,275);
       QLabel *qlabel510=new QLabel(this);
       qlabel510->move(255,315);
       for(int i=0;i<V;i++){
           for (int j=0;j<V;j++) {
               int temp5=tempcost[i][j];
               if(i+1==1&&temp5!=1024){
                   switch (j+1) {
                   case 2:
                       qlabel51->setNum(temp5);
                       qlabel51->show();
                       break;
                   case 3:
                       qlabel52->setNum(temp5);
                       qlabel52->show();
                       break;
                   case 4:
                       qlabel58->setNum(temp5);
                       qlabel58->show();
                       break;
                   case 5:
                       qlabel56->setNum(temp5);
                       qlabel56->show();
                       break;


                   }
               }
               if(i+1==2&&temp5!=1024){
                   switch (j+1) {
                   case 1:
                       qlabel51->setNum(temp5);
                       qlabel51->show();
                       break;
                   case 3:
                       qlabel57->setNum(temp5);
                       qlabel57->show();
                       break;
                   case 4:
                       qlabel59->setNum(temp5);
                       qlabel59->show();
                       break;
                   case 5:
                       qlabel55->setNum(temp5);
                       qlabel55->show();
                       break;


                   }
               }
               if(i+1==3&&temp5!=1024){
                   switch (j+1) {
                   case 1:
                       qlabel52->setNum(temp5);
                       qlabel52->show();
                       break;
                   case 2:
                       qlabel56->setNum(temp5);
                       qlabel53->show();
                       break;
                   case 4:
                       qlabel53->setNum(temp5);
                       qlabel53->show();
                       break;
                   case 5:
                       qlabel510->setNum(temp5);
                       qlabel510->show();
                       break;
                   }
               }
               if(i+1==4&&temp5!=1024){
                   switch (j+1) {
                   case 1:
                       qlabel58->setNum(temp5);
                       qlabel58->show();
                       break;
                   case 2:
                       qlabel59->setNum(temp5);
                       qlabel59->show();
                       break;
                   case 3:
                       qlabel53->setNum(temp5);
                       qlabel53->show();
                       break;
                   case 5:
                       qlabel54->setNum(temp5);
                       qlabel54->show();
                       break;
                   }
               }
               if(i+1==5&&temp5!=1024){
                   switch (j+1) {
                   case 1:
                       qlabel56->setNum(temp5);
                       qlabel56->show();
                       break;
                   case 2:
                       qlabel55->setNum(temp5);
                       qlabel55->show();
                       break;
                   case 3:
                       qlabel510->setNum(temp5);
                       qlabel510->show();
                       break;
                   case 4:
                       qlabel54->setNum(temp5);
                       qlabel54->show();
                       break;
                   }
               }
           }
       }
    }
    //绘制表格中的元素
    QLabel *qlink=new QLabel(this);
    qlink->setText("Link");
    qlink->move(50,500);
    qlink->show();
    QLabel *qboolconnect=new QLabel(this);
    qboolconnect->setText("Bool");
    qboolconnect->move(100,500);
    qboolconnect->show();
    QLabel *qdistance=new QLabel(this);
    qdistance->setText("Distance");
    qdistance->move(150,500);
    qdistance->show();
    QLabel *qfrom=new QLabel(this);
    qfrom->setText("begin point");
    qfrom->move(50,465);
    qfrom->show();
    QLabel *qrandfrom=new QLabel(this);
    qrandfrom->setNum(randfrom);
    qrandfrom->move(180,465);
    qrandfrom->show();

    //高亮显示
    if(V==4){
    QLabel *throughout41=new QLabel (this);
    throughout41->move(140,120);
    QLabel *throughout42=new QLabel(this);
    throughout42->move(360,120);
    QLabel *throughout43=new QLabel (this);
    throughout43->move(140,300);
    QLabel *throughout44=new QLabel (this);
    throughout44->move(360,300);
    switch (randfrom) {
    case 1:
        throughout41->setText("OK");
        throughout41->show();
        break;
    case 2:
        throughout42->setText("OK");
        throughout42->show();
        break;
    case 3:
        throughout43->setText("OK");
        throughout43->show();
        break;
    case 4:
        throughout44->setText("OK");
        throughout44->show();
        break;


          }

    if(clickcount==1){
        cout<<"clickcount"<<clickcount<<endl;
    switch (pcross[1]) {
        case 1:
         throughout41->setText("OK");
         throughout41->show();
        break;
       case 2:
        throughout42->setText("OK");
        throughout42->show();
        break;
       case 3:
        throughout43->setText("OK");
        throughout43->show();
        break;
       case 4:
        throughout44->setText("OK");
        throughout44->show();
        break;

        }
    }
    if(clickcount==2){
        cout<<"clickcount"<<clickcount<<endl;
    switch (pcross[2]) {
        case 1:
         throughout41->setText("OK");
         throughout41->show();
        break;
       case 2:
        throughout42->setText("OK");
        throughout42->show();
        break;
       case 3:
        throughout43->setText("OK");
        throughout43->show();
        break;
       case 4:
        throughout44->setText("OK");
        throughout44->show();
        break;

        }
    }
    if(clickcount==3){
        cout<<"clickcount"<<clickcount<<endl;
    switch (pcross[3]) {
        case 1:
         throughout41->setText("OK");
         throughout41->show();
        break;
       case 2:
        throughout42->setText("OK");
        throughout42->show();
        break;
       case 3:
        throughout43->setText("OK");
        throughout43->show();
        break;
       case 4:
        throughout44->setText("OK");
        throughout44->show();
        break;

        }
      }
    }
    if(V==5){
        QLabel *throughout51=new QLabel(this);
        throughout51->move(150,120);
        QLabel *throughout52=new QLabel(this);
        throughout52->move(370,120);
        QLabel *throughout53=new QLabel(this);
        throughout53->move(120,315);
        QLabel *throughout54=new QLabel(this);
        throughout54->move(260,430);
        QLabel *throughout55=new QLabel(this);
        throughout55->move(390,315);
        switch (randfrom) {
        case 1:
            throughout51->setText("OK");
            throughout51->show();
            break;
        case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
        case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
        case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
        case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;

              }
        if(clickcount==1){
            cout<<"clickcount"<<clickcount<<endl;
        switch (pcross[1]) {
            case 1:
             throughout51->setText("OK");
             throughout51->show();
            break;
           case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
           case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
           case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
           case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;

            }
        }
        if(clickcount==2){
            cout<<"clickcount"<<clickcount<<endl;
        switch (pcross[2]) {
            case 1:
             throughout51->setText("OK");
             throughout51->show();
            break;
           case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
           case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
           case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
        case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;
            }
        }
        if(clickcount==3){
            cout<<"clickcount"<<clickcount<<endl;
        switch (pcross[3]) {
            case 1:
             throughout51->setText("OK");
             throughout51->show();
            break;
           case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
           case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
           case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
        case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;

            }
          }if(clickcount==4){
            cout<<"clickcount"<<clickcount<<endl;
        switch (pcross[4]) {
            case 1:
             throughout51->setText("OK");
             throughout51->show();
            break;
           case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
           case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
           case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
        case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;

            }
          }
        if(clickcount==5){
            cout<<"clickcount"<<clickcount<<endl;
        switch (pcross[5]) {
            case 1:
             throughout51->setText("OK");
             throughout51->show();
            break;
           case 2:
            throughout52->setText("OK");
            throughout52->show();
            break;
           case 3:
            throughout53->setText("OK");
            throughout53->show();
            break;
           case 4:
            throughout54->setText("OK");
            throughout54->show();
            break;
        case 5:
            throughout55->setText("OK");
            throughout55->show();
            break;

            }
          }


    }

}

void QLabel::setNum(int num)
{
    QString str;
    str.setNum(num);
    setText(str);
}
int main(int argc, char *argv[])
{
    init();
    QApplication a(argc, argv);
    Widget w;
    w.show();
    w.resize(700,650);
    w.setWindowTitle("Dijkstra");

    return a.exec();

 }
