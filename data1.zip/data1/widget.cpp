#include "widget.h"
#include "ui_widget.h"
#include<QPen>
#include<QPainter>
#include<iostream>
using namespace std;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    x=0;
}

Widget::~Widget()
{
    delete ui;
}


